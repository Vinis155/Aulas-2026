import { useState } from "react";
import { View, TextInput, Button } from "react-native";
import { useRouter } from "expo-router";

export default function AddTaskScreen() {
  const [text, setText] = useState("");

  const router = useRouter();

  function handleAdd() {}

  return (
    <View style={{ padding: 20 }}>
      <TextInput
        placeholder="Digite a tarefa"
        value={text}
        onChangeText={setText}
        style={{ borderWidth: 1, marginBottom: 10, padding: 10 }}
      />

      <Button title="Adicionar" onPress={handleAdd} />
    </View>
  );
}
