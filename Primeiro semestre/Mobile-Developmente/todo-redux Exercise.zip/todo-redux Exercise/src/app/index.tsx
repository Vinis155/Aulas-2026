import { View, Text, FlatList, Button, TextInput } from "react-native";
import { useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";

export default function TaskList() {
  const tasks = useSelector((state: RootState) => state.tasks.tasks);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [newText, setNewText] = useState("");

  const router = useRouter();

  function handleUpdate(id: string) {
    setEditingId(null);
    setNewText("");
  }

  return (
    <SafeAreaView style={{ flex: 1, padding: 20 }}>
      <Button title="Nova Tarefa" onPress={() => router.push("/addTask")} />

      <FlatList
        data={tasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={{ marginTop: 15 }}>
            {editingId === item.id ? (
              <>
                <TextInput
                  value={newText}
                  onChangeText={setNewText}
                  style={{ borderWidth: 1, padding: 8 }}
                />
                <Button title="Salvar" onPress={() => handleUpdate(item.id)} />
              </>
            ) : (
              <>
                <Text>{item.title}</Text>

                <Button
                  title="Editar"
                  onPress={() => {
                    setEditingId(item.id);
                    setNewText(item.title);
                  }}
                />

                <Button
                  title="Remover"
                  onPress={() => dispatch(removeTask(item.id))}
                />
              </>
            )}
          </View>
        )}
      />
    </SafeAreaView>
  );
}
